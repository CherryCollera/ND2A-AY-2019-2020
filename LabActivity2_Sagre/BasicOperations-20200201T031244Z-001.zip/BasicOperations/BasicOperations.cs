﻿using System;

namespace BasicOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;

            Console.WriteLine("Enter first number: ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter second number: ");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Sum= {0}     ", num1 + num2);
            Console.Write("diffence= {0}     ", num1 - num2);
            Console.Write("product= {0}     ", num1 * num2);
            Console.Write("quotient= {0}     ", num1 / num2);
            Console.Write("remainder= {0}     ", num1 % num2);
            Console.ReadLine();
        }
    }
}